package org.example.demo;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
public class HelloApplication extends Application {
    private Scene initialScene;
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Biodata Mahasiswa");
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        Label nameLabel = new Label("Name:");
        GridPane.setConstraints(nameLabel, 0, 0);
        TextField nameInput = new TextField();
        GridPane.setConstraints(nameInput, 1, 0);

        Label nimLabel = new Label("NIM:");
        GridPane.setConstraints(nimLabel, 0, 1);
        TextField nimInput = new TextField();
        GridPane.setConstraints(nimInput, 1, 1);

        Label classLabel = new Label("Class:");
        GridPane.setConstraints(classLabel, 0, 2);
        TextField classInput = new TextField();
        GridPane.setConstraints(classInput, 1, 2);

        Label emailLabel = new Label("E-mail:");
        GridPane.setConstraints(emailLabel, 0, 3);
        TextField emailInput = new TextField();
        GridPane.setConstraints(emailInput, 1, 3);

        Button searchButton = new Button("Search");
        GridPane.setConstraints(searchButton, 1, 4);
        grid.getChildren().addAll(nameLabel, nameInput, nimLabel, nimInput, classLabel, classInput, emailLabel, emailInput, searchButton);

        initialScene = new Scene(grid, 300, 200);
        primaryStage.setScene(initialScene);
        searchButton.setOnAction(e -> {
            String name = nameInput.getText();
            String nim = nimInput.getText();
            String className = classInput.getText();
            String email = emailInput.getText();

            if (name.isEmpty() || nim.isEmpty() || className.isEmpty() || email.isEmpty()) {
                System.out.println("Kolom tidak boleh kosong");
            } else {
                VBox newSceneLayout = new VBox(10);
                newSceneLayout.setPadding(new Insets(20, 20, 20, 20));
                Label welcomeLabel = new Label("Selamat datang , " + name + "!");
                newSceneLayout.getChildren().add(welcomeLabel);

                Button submitButton = new Button("Submit");
                newSceneLayout.getChildren().add(submitButton);
                submitButton.setOnAction(event -> {
                    System.out.println("Name: " + name);
                    System.out.println("NIM: " + nim);
                    System.out.println("Class: " + className);
                    System.out.println("E-mail: " + email);
                });
                Button backButton = new Button("Kembali");
                newSceneLayout.getChildren().add(backButton);
                backButton.setOnAction(event -> {
                    primaryStage.setScene(initialScene);
                });
                Scene newScene = new Scene(newSceneLayout, 300, 200);
                primaryStage.setScene(newScene);
            }
        });
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}
